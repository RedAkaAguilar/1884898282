let l = bl? 1: -1;
global.fall = 0.0;
global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;


let ptAngle = mainHand? pitchAngle : pitchAngleO;
let ywAngle = mainHand? yawAngle : yawAngleO;

let itemIds = [
"minecraft:bell"
];

for (let id of itemIds) {
    renderAsBlock.put(id, false);
}

if (I.isOf(item, Items.get("minecraft:name_tag"))) {
    M.moveY(matrices, -0.2);
    M.rotateX(matrices, -95);

    swingProgress = 0;
	M.rotateX(matrices, M.clamp(P.getPitch(player) / 2.5, -25, 90) + ptAngle)
	M.rotateZ(matrices, ywAngle * -1, 0, 0, 0.1)
}

if (I.isOf(item, Items.get("minecraft:totem_of_undying"))){
    M.moveY(matrices, 0.125);
    M.moveX(matrices, -0.15 * l);
    M.rotateX(matrices, -10);
    M.rotateY(matrices, 55 * l);
	I.setTranslate(item, true);
    particleManager.addParticle(particles, 
        false, 
        0.5 * l, 
        0.1, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        0, 
        2.5, Texture.of("minecraft", "textures/particle/glow.png"), "ITEM", hand, "SPAWN", "ADDITIVE", 0, 200 + (20 * M.sin(P.getAge(player) * 0.2)));
}

if (I.isOf(item, Items.get("minecraft:bell"))){
   M.moveY(matrices, 0.6);
}

if (I.isOf(item, Items.get("minecraft:trident"))){
   M.moveY(matrices, -0.4);
}

if (I.isOf(item, Items.get("minecraft:shears"))){
   M.moveZ(matrices, -0.1);
   M.rotateZ(matrices, -45);
}