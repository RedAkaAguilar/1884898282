local l = (bl and 1) or -1

global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local physicsItems = {
    "minecraft:elytra"
}



for _, physicsItem in ipairs(physicsItems) do
    if I:isOf(item, Items:get(physicsItem)) then
        M:moveY(matrices, -0.75)
        M:moveX(matrices, 0.1*l)
        M:moveZ(matrices, -0.2)
        M:rotateZ(matrices, 90*l)
        M:rotateX(matrices, -20)
        M:rotateY(matrices, -10*l)
    end
end
