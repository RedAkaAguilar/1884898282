global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;


let ptAngle = mainHand? pitchAngle : pitchAngleO;
let ywAngle = mainHand? yawAngle : yawAngleO;


if (I.isOf(item, Items.get("minecraft:name_tag"))) {
    M.moveZ(matrices, 0.05)
	M.moveY(matrices, -0.1)
	M.rotateX(matrices, 25)
}