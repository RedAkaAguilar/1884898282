local l = (bl and 1) or -1
local d = (bl and 1) or -0.8
local a = (bl and 1) or -0.05
local n = (bl and 1) or 0.8

global.fall_l = 0.0; 
global.pitchAngle = 0.0;
global.yawAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO
 --get the fuck out of my code
 
local physicsItems = {
    "minecraft:elytra"
}

for _, physicsItem in ipairs(physicsItems) do
	if I:isOf(item, Items:get(physicsItem)) then
		M:moveY(matrices, -0.2)
		M:rotateX(matrices, -70)
		M:rotateX(matrices, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle + ywAngle * 0.5, 0, -0.13, 0)
		M:rotateZ(matrices, ywAngle * -0.7, -0.1 * l, 0, 0.1)
	end
end

if I:isOf(item, Items:get("minecraft:elytra")) then
	M:scale(matrices, 1.4, 1.4, 1.4)
    M:moveX(matrices, 0.011*l)
end


